I was worried you wouldn't read the actual README.md which tells you my simple make commands:

```
make
// Output: g++ main.cpp
make r
// Output: ...Code Demo...
```
