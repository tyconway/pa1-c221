# pa1-c221
Project 1 for CSCE 221 Data Structures.

Created a github repo for cross-machine development and for further practice with git workflow.

## For Graders
I've created a makefile to simplify your lives.
To build project:
```
make
// Output: g++ main.cpp
make r
// Output: ...Code Demo...
```
Note: in its current state, the project will not run the experimental trials. To change this, modify the value of `pushes` currently in `main.cpp` on line (85).
